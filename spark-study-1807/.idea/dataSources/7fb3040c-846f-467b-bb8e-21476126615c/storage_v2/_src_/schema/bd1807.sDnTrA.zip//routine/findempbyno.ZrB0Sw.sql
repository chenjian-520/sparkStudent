create procedure findEmpByNo(IN dno int)
  begin
		select * from emp where deptno=dno;
	end;

