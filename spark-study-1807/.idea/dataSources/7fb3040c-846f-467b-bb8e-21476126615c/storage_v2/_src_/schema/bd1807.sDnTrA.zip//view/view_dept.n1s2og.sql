create view view_dept as
  select
    `bd1807`.`emp`.`deptno`   AS `deptno`,
    `bd1807`.`emp`.`empno`    AS `empno`,
    `bd1807`.`emp`.`ename`    AS `ename`,
    `bd1807`.`emp`.`job`      AS `job`,
    `bd1807`.`emp`.`mgr`      AS `mgr`,
    `bd1807`.`emp`.`hiredate` AS `hiredate`,
    `bd1807`.`emp`.`sal`      AS `sal`,
    `bd1807`.`emp`.`comm`     AS `comm`,
    `bd1807`.`dept`.`dname`   AS `dname`,
    `bd1807`.`dept`.`loc`     AS `loc`
  from (`bd1807`.`emp`
    join `bd1807`.`dept` on ((`bd1807`.`emp`.`deptno` = `bd1807`.`dept`.`deptno`)));

