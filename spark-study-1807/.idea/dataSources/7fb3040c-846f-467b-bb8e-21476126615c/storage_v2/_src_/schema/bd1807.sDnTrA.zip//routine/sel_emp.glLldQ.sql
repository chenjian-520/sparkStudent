create procedure sel_emp()
  begin
 #sql
 select dname ,ename from emp ,dept where emp.deptno=dept.deptno;
end;

