create trigger tig_emp_copy1
  after DELETE
  on emp_copy1
  for each row
  begin 
	insert into use_bak values(old.empno,old.ename,old.job,old.mgr,old.hiredate,old.sal,old.comm,old.deptno);
end;

