create procedure score_levelk(IN score int)
  begin
	#å˜é‡å£°æ˜Ž
	 declare v_level varchar(20);
		if score > 80 then 
		#å˜é‡èµ‹å€¼
			set v_level = 'A';
		elseif score >=60 then
			set v_level = 'B';
		else
			set v_level = 'C';
		end if;
	select v_level;	
	end;

