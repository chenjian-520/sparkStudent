create procedure calc()
  begin
 declare i int;
 declare sum int;
 set i = 1;
 set sum = 0;
 while i<=100 do
 
 set sum = i +sum;
 set i = i+1;
 
 end while; 
select sum;

end;

