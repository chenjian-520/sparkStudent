create procedure calc1()
  begin
 declare i int;
 declare sum int;
 set i = 1;
 set sum = 0;
 lip:loop  
		set sum = i +sum;
		set i = i+1;
		if i>100 then  
		 leave lip;
		 end if;
 end loop; 
select sum;

end;

