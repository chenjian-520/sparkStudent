create trigger tig_emp
  after DELETE
  on emp
  for each row
  begin 
	insert into use_bak values(old.empno,old.ename,old.job,old.mgr,old.hiredate,old.sal,old.comm,old.deptno);
end;

