create procedure calc2()
  begin
 declare i int;
 declare sum int;
 set i = 1;
 set sum = 0;
 repeat 
		set sum = i +sum;
		set i = i+1;
	until i>100
 end repeat; 
select sum;

end;

