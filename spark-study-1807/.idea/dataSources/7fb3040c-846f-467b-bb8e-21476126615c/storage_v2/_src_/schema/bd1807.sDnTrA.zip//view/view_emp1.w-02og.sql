create view view_emp1 as
  select
    `bd1807`.`emp`.`empno`    AS `empno`,
    `bd1807`.`emp`.`ename`    AS `ename`,
    `bd1807`.`emp`.`job`      AS `job`,
    `bd1807`.`emp`.`mgr`      AS `mgr`,
    `bd1807`.`emp`.`hiredate` AS `hiredate`,
    `bd1807`.`emp`.`sal`      AS `sal`,
    `bd1807`.`emp`.`comm`     AS `comm`,
    `bd1807`.`emp`.`deptno`   AS `deptno`
  from `bd1807`.`emp`
  where (`bd1807`.`emp`.`deptno` = 20);

