create procedure findNameByNo(IN eno int, OUT v_name varchar(20))
  begin
	select ename into v_name from emp where empno = eno ;
end;

