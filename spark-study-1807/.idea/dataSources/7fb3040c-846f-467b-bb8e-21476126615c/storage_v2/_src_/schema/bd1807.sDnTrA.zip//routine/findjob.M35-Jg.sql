create procedure findJob(INOUT name_job varchar(20))
  begin
	select job into name_job from emp where ename = name_job;
end;

